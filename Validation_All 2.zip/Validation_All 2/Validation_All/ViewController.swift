
import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtemail: UITextField!
    @IBOutlet weak var txtphone: UITextField!
    @IBOutlet weak var txtmobile: UITextField!
    @IBOutlet weak var txtpwd: UITextField!
    @IBOutlet weak var instructionView: UIView!
    @IBOutlet weak var lblInstruction: UILabel!
    @IBOutlet weak var btnShow: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    @IBAction func Emailtextfileddidchange(_ sender: UITextField) {
    
        if isValidEmail(email: txtemail.text!) {
            
            txtemail.rightViewMode = .never
            txtemail.clipsToBounds = true
            txtemail.layer.borderWidth = 1
            txtemail.layer.borderColor = UIColor.green.cgColor
        }
        else {
            
            txtemail.rightViewMode = .whileEditing
            let imgview = UIImageView(image: UIImage(named: "if_Help_mark_query_question_support_talk_271504.png"))
            txtemail.rightView = imgview
            
            txtemail.clipsToBounds = true
            txtemail.layer.borderWidth = 1
            txtemail.layer.borderColor = UIColor.red.cgColor
        }
        lblInstruction.text = "Enter in this format : Firstpart@secondPart.domainname"
    }
    
    @IBAction func Phonetextfielddidchange(_ sender: UITextField) {
    
        if isValidPhone(phone: txtphone.text!) {
            
            txtphone.rightViewMode = .never
            txtphone.clipsToBounds = true
            txtphone.layer.borderWidth = 1
            txtphone.layer.borderColor = UIColor.green.cgColor
        }
        else {
            
            txtphone.rightViewMode = .whileEditing
            let imgview = UIImageView(image: UIImage(named: "if_Help_mark_query_question_support_talk_271504.png"))
            txtphone.rightView = imgview
            txtphone.clipsToBounds = true
            txtphone.layer.borderWidth = 1
            txtphone.layer.borderColor = UIColor.red.cgColor
        }
        lblInstruction.text = "Enter in this format : 12345-123-123"
    }
    
    @IBAction func Mobiletextfielddidchange(_ sender: UITextField) {
    
        if isValidMobile(mobile: txtmobile.text!) {
            
            txtmobile.rightViewMode = .never
            txtmobile.clipsToBounds = true
            txtmobile.layer.borderWidth = 1
            txtmobile.layer.borderColor = UIColor.green.cgColor
        }
        else {
            
            txtmobile.rightViewMode = .whileEditing
            let imgview = UIImageView(image: UIImage(named: "if_Help_mark_query_question_support_talk_271504.png"))
            txtmobile.rightView = imgview
            txtmobile.clipsToBounds = true
            txtmobile.layer.borderWidth = 1
            txtmobile.layer.borderColor = UIColor.red.cgColor
        }
        lblInstruction.text = "Enter in this format : STARTING WITH +91 THEN ONE DIGIT START BETWEEN 7 TO 9 THEN ADD 9 DIGIT BETWEEN 0 TO 9 IT PERMITS +919726174054 / 09726174054"
    }

    @IBAction func Passwordtextfielddidchange(_ sender: Any) {
    
        if isValidPassword(pwd: txtpwd.text!) {
            
            txtpwd.rightViewMode = .never
            txtpwd.clipsToBounds = true
            txtpwd.layer.borderWidth = 1
            txtpwd.layer.borderColor = UIColor.green.cgColor
        }
        else {
            
            txtpwd.rightViewMode = .whileEditing
            let imgview = UIImageView(image: UIImage(named: "if_Help_mark_query_question_support_talk_271504.png"))
            txtpwd.rightView = imgview
            txtpwd.clipsToBounds = true
            txtpwd.layer.borderWidth = 1
            txtpwd.layer.borderColor = UIColor.red.cgColor
        }
         lblInstruction.text = "Enter in this format : Minimum 6 Max 8 characters at least 1 Alphabet, 1 Number and 1 Special Character:"
    }
    
    func isValidEmail(email:String) -> Bool {
        
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        let result = emailTest.evaluate(with: email)
        return result
    }

    func isValidPhone(phone: String) -> Bool {
        
        let PHONE_REGEX = "^\\d{5}-\\d{3}-\\d{3}$"
        let phoneTest = NSPredicate(format: "SELF MATCHES %@", PHONE_REGEX)
        let result =  phoneTest.evaluate(with: phone)
        return result
    }
    
    func isValidMobile(mobile: String) -> Bool {
        
        //STARTING WITH +91 THEN ONE DIGIT START BETWEEN 7 TO 9 THEN ADD 9 DIGIT BETWEEN 0 TO 9 IT PERMITS +919726174054 / 09726174054
        
        let PHONE_REGEX = "^([+][9][1]|[9][1]|[0]){0,1}([7-9]{1})([0-9]{9})$"
        
        let phoneTest = NSPredicate(format: "SELF MATCHES %@", PHONE_REGEX)
        let result =  phoneTest.evaluate(with: mobile)
        return result
    }

    func isValidPassword(pwd: String) -> Bool {
        
        //Minimum 6 Max 8 characters at least 1 Alphabet, 1 Number and 1 Special Character:
        let PHONE_REGEX = "^(?=.*[A-Za-z])(?=.*\\d)(?=.*[$@$!%*#?&])[A-Za-z\\d$@$!%*#?&]{6,8}$"
        let phoneTest = NSPredicate(format: "SELF MATCHES %@", PHONE_REGEX)
        let result =  phoneTest.evaluate(with: pwd)
        return result
    }
    @IBAction func btnShowHide(_ sender: UIButton) {
    
        if btnShow.titleLabel?.text == "Show" {
            
            txtpwd.isSecureTextEntry = false
            btnShow.setImage(UIImage(named: "if_eye_1545742.png"), for: .normal)
            btnShow.setTitle("Hide", for: .normal)
        }
        else {
            
            txtpwd.isSecureTextEntry = true
            btnShow.setImage(UIImage(named: "if_icon-21-eye-hidden_314858.png"), for: .normal)
            btnShow.setTitle("Show", for: .normal)
        }
    }
    
    @IBAction func btnCheck(_ sender: Any) {
    
        if txtemail.text != "" && txtphone.text != "" && txtmobile.text != "" && txtpwd.text != "" {
            
            if isValidEmail(email: txtemail.text!) {
                
                if isValidPhone(phone: txtphone.text!){
                    
                    if isValidMobile(mobile: txtmobile.text!) {
                        
                        if isValidPassword(pwd: txtpwd.text!){
                            
                            print("Success")
                        }else {
                            
                            print("Enter valid password!")
                        }
                    }else {
                        
                        print("Enter valid mobile!")
                    }
                }else {
                    
                    print("Enter valid phone!")
                }
            }else {
                
                print("Enter valid e_mail!")
            }
        }
        else {
            
            print("Kindly enter fully detail")
        }

    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    
    }


}

